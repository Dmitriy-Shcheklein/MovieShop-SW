import React from 'react';
import FigurineListItem from './FigurineListItem';
import { useSelector, useDispatch } from 'react-redux';



const FigurineList = () => {

  // const dispatch = useDispatch();
  const figurines = useSelector((state) => state.figurines)

  const onAddedToCart = () => console.log("fdfdsf");


  return (
    <ul className='list'>
      {
        figurines.map((figurine, idx) => {
          return (
            <li
              className='listItem'
              key={idx}>
              <FigurineListItem
                figurine={figurine}
                onAddToCart={() => onAddedToCart()}
              />
            </li>
          );
        })
      }
    </ul>
  )
}

export default FigurineList;