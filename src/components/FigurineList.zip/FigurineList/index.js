import FigurineListContainer from "./FigurineListContainer";

export default FigurineListContainer;