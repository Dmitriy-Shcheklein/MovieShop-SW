import FigurineListItem from "./FigurineListItem";

export default FigurineListItem;